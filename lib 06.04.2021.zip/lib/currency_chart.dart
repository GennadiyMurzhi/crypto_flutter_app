import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class CurrencyChart extends StatelessWidget{
  // TODO: implement build
  final List<double> dataCurrency;

  CurrencyChart(this.dataCurrency);

  Widget build(BuildContext context) {
    return Stack(
      children: [
        CustomPaint(
          painter: CurrencyChartPainter(dataCurrency),
          child: Container(),
        ),
        GradientPart(dataCurrency)
      ]
    );
  }

}

class DetailCurrencyChart extends StatefulWidget{
  final List<double> dataCurrency;

  DetailCurrencyChart(this.dataCurrency);

  @override
  _DetailCurrencyChartState createState() =>
      _DetailCurrencyChartState();
}

class _DetailCurrencyChartState extends State<DetailCurrencyChart>{

  Offset _tap;
  Offset _leftPoint;
  Offset _rightPoint;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Stack(
        children: [
          CustomPaint(
            painter: CurrencyChartDetailPainter(widget.dataCurrency, _leftPoint,
            _rightPoint),
            child: Container()
          ),
          GradientPart(widget.dataCurrency),
          Container(
            child: GestureDetector(
              onTapDown: (tapPoint){
                _tap = tapPoint.localPosition;
                if(_leftPoint == null)_leftPoint = tapPoint.localPosition; //1
                else if(_leftPoint != null && _rightPoint == null){ //2
                  if(tapPoint.localPosition.dx < _leftPoint.dx){
                    _rightPoint = _leftPoint;
                    _leftPoint = tapPoint.localPosition;
                  } else if(tapPoint.localPosition.dx > _leftPoint.dx)
                    _rightPoint = tapPoint.localPosition;
                  else _leftPoint = tapPoint.localPosition;
                } else if(_leftPoint != null && _rightPoint != null){ //3
                  double distancePoints = _rightPoint.dx - _leftPoint.dx;
                  if(tapPoint.localPosition.dx == _leftPoint.dx + distancePoints / 2) { // 3.1
                    if(Random().nextBool()) _leftPoint = tapPoint.localPosition;
                    else _rightPoint = tapPoint.localPosition;
                  } else if(_leftPoint.dx < tapPoint.localPosition.dx
                      && tapPoint.localPosition.dx < _leftPoint.dx + distancePoints / 2) // 3.2
                    _leftPoint = tapPoint.localPosition;
                  else if(_leftPoint.dx + distancePoints / 2 < tapPoint.localPosition.dx
                  && tapPoint.localPosition.dx < _rightPoint.dx) // 3.3
                    _rightPoint = tapPoint.localPosition;
                  else if(tapPoint.localPosition.dx <= _leftPoint.dx) // 3.4
                    _leftPoint = tapPoint.localPosition;
                  else if(tapPoint.localPosition.dx >= _rightPoint.dx) // 3.5
                    _rightPoint = tapPoint.localPosition;
                }
                setState(() {});
              },
            ),
          )
        ]
    );
  }
}

class GradientPart extends StatelessWidget{
  final List<double> dataCurrency;

  const GradientPart(this.dataCurrency);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ClipPath(
      clipper: GradientClipper(dataCurrency.reduce(max), dataCurrency),
      child: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromRGBO(33, 30, 255, 0.3),
                  Color.fromRGBO(255, 255, 255, 0)
                ]
            )
        ),
      ),
    );
  }

}

class MakeCurrencyPath {

  var _path = Path();

  double _stepChart;
  Offset _startFirstArc;
  Offset _endFirstArc;
  Offset _startSecondArc;
  Offset _endSecondArc;
  double _oddsPoints;
  bool _clockwiseArc;

  Path makePath (List<double> dataCurrency, double widthContainer){
    double step = getStep(dataCurrency, widthContainer);
    Path path = Path();
    path.moveTo(0, dataCurrency[0]);

    for (int i = 1; i < dataCurrency.length; i++) {
      if (dataCurrency[i] == dataCurrency[i - 1])
        path.lineTo(i * step, dataCurrency[i]);
      else if (i == dataCurrency.length - 1)
        _addPartCurrencyPath(
            path, i * step, step, dataCurrency[i], dataCurrency[i - 1]);
      else
        _addPartCurrencyPath(
            path, i * step, step, dataCurrency[i], dataCurrency[i - 1],
            futurePositionCurrency: dataCurrency[i + 1]);
    }
    return path;
  }

  Path get currencyPath => _path;

  double getStep(List<double> dataCurrency, double widthContainer) =>
      widthContainer/(dataCurrency.length-1);

  void _addPartCurrencyPath(Path path, double stepChart, double step,
      double positionCurrency, double lastPositionCurrency,
      {double futurePositionCurrency}){
    _oddsPoints  = positionCurrency - lastPositionCurrency;
    if(_oddsPoints>0) _clockwiseArc = true; else _clockwiseArc = false;
    _startFirstArc = Offset(stepChart - step, lastPositionCurrency);
    _endFirstArc = Offset(stepChart - step/2, lastPositionCurrency + _oddsPoints/6);
    _startSecondArc = Offset(stepChart - step/2, positionCurrency - _oddsPoints/6);
    _endSecondArc = Offset(stepChart, positionCurrency);

    if(futurePositionCurrency == null) path.arcToPoint(_endFirstArc,
        radius: Radius.circular(_oddsPoints/4), clockwise: _clockwiseArc);
    else if(positionCurrency > futurePositionCurrency)
      path.arcToPoint(_endFirstArc, radius: Radius.circular(_oddsPoints/4), clockwise: _clockwiseArc);
    else path.arcToPoint(_endFirstArc, radius: Radius.circular(_oddsPoints/4), clockwise: _clockwiseArc);
    path.lineTo(_startSecondArc.dx, _startSecondArc.dy);
    if(futurePositionCurrency == null) path.arcToPoint(_endSecondArc,
        radius: Radius.circular(_oddsPoints/2), clockwise: !_clockwiseArc);
    else if(positionCurrency > futurePositionCurrency)
      path.arcToPoint(_endSecondArc, radius: Radius.circular(_oddsPoints/4), clockwise: !_clockwiseArc);
    else path.arcToPoint(_endSecondArc, radius: Radius.circular(_oddsPoints/4), clockwise: !_clockwiseArc);
  }
}

class CurrencyChartPainter extends CustomPainter with MakeCurrencyPath{

  final List<double> dataCurrency;

  CurrencyChartPainter(this.dataCurrency);

  @override
  void paint(Canvas canvas, Size size) {
    // TODO: implement paint

    drawChart(canvas, size);

    drawSeparatedLine(canvas, size);

  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    // TODO: implement shouldRepaint
    return false;
  }

  void drawChart(Canvas canvas, Size size){
    var paint = Paint()
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..shader = ui.Gradient.linear(
          Offset(size.width/2,0),
          Offset(size.width/2, size.height),
          [
            Color.fromRGBO(255, 25, 233, 1),
            Color.fromRGBO(33, 30, 255, 1)
          ]
      );

    var path = makePath(dataCurrency, size.width);
    canvas.drawPath(path, paint);
    canvas.save();
    canvas.restore();
  }

  void drawSeparatedLine(Canvas canvas, Size size){
    var paint = Paint()
      ..color = Colors.grey.withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    double partLineLength = size.width/100;
    double lineLength = 0;

    double centerHeightChart = (dataCurrency.reduce(max)
        + dataCurrency.reduce(min)) / 2;

    var path = Path();

    while(lineLength <= size.width){
      path.moveTo(lineLength, centerHeightChart);
      path.lineTo(lineLength + partLineLength, centerHeightChart);
      lineLength += (partLineLength + size.width/800) * 4;
    }

    canvas.drawPath(path, paint);
    canvas.save();
    canvas.restore();
  }

}

class GradientClipper extends CustomClipper<Path> with MakeCurrencyPath{
  final List dataCurrency;
  final double maxData;
  Path _currencyPath;

  GradientClipper(this.maxData, this.dataCurrency);

  @override
  Path getClip(Size size) {
    // TODO: implement getClip
    _currencyPath = makePath(dataCurrency, size.width);
    _currencyPath.lineTo(size.width, maxData);
    _currencyPath.lineTo(0, maxData);
    _currencyPath.close();

    return _currencyPath;
  }

  @override
  bool shouldReclip(covariant CustomClipper oldClipper) {
    // TODO: implement shouldReclip
    return true;
  }
}

class CurrencyChartDetailPainter extends CurrencyChartPainter{
  Offset _leftPoint;
  Offset _rightPoint;

  CurrencyChartDetailPainter(List<double> dataCurrency, this._leftPoint,
      this._rightPoint) : super(dataCurrency);

  @override
  void paint(ui.Canvas canvas, ui.Size size) {
    // TODO: implement paint
    if(_leftPoint != null) drawBackgroundCircle(canvas,
        getSCurrencyPoint(_leftPoint.dx, size.width), 3);
    if(_rightPoint != null) drawBackgroundCircle(canvas,
        getSCurrencyPoint(_rightPoint.dx, size.width), 3);

    drawChart(canvas, size);

    drawSeparatedLine(canvas, size);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    // TODO: implement shouldRepaint
    return true;
  }

  void drawBackgroundCircle(Canvas canvas, Offset currencyPoint,
      double strokeWidth){
    var paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..color = Colors.grey.withOpacity(0.5);

    canvas.drawCircle(currencyPoint, strokeWidth * 2, paint);
  }

  Offset getSCurrencyPoint(double abscissa, double widthContainer) {
    Offset point;
    double step = getStep(dataCurrency, widthContainer);
    for (int i = 0; i < dataCurrency.length - 1; i++) {
      if (i * step <= abscissa && (i + 1) * step >= abscissa) {
        double middleStepChart = i * step + step / 2;
        switch (middleStepChart.compareTo(abscissa)) {
          case -1:
            point = Offset((i + 1) * step, dataCurrency[i + 1]);
            break;
          case 1:
            point = Offset(i * step, dataCurrency[i]);
            break;
          case 0:
            if (Random().nextBool())
              point = Offset((i + 1) * step, dataCurrency[i + 1]);
            else
              point = Offset(i * step, dataCurrency[i]);
            break;
        }
      }
    }
    return point;
  }
}